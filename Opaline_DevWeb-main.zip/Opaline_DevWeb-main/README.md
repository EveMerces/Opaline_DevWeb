## Seja bem vindo ao Opaline_DevWeb!

Documentação de api para a utilização do projeto: https://github.com/EveMerces/project-dw 

🔧 Funcionalidades

🔹 Página Inicial: Exibe produtos disponíveis na loja

🔹 Sobre nós: Projeto de desenvolvimento web voltado para criar soluções intuitivas e eficientes, com foco em qualidade, segurança e performance.

🔹 Cadastro de Usuário: Permite criar uma conta na plataforma

Tecnologias Utilizadas no Desenvolvimento:

| Linguagem   | Ícone  |
|------------|--------|
| HTML       | ![HTML](https://cdn.jsdelivr.net/gh/devicons/devicon/icons/html5/html5-original.svg) |
| CSS        | ![CSS](https://cdn.jsdelivr.net/gh/devicons/devicon/icons/css3/css3-original.svg) |
| JavaScript | ![JavaScript](https://cdn.jsdelivr.net/gh/devicons/devicon/icons/javascript/javascript-original.svg) |
